from setuptools import find_packages, setup

with open("Readme.md", "r") as f:
    long_description = f.read()

setup(
    name="ReliabilityPackage",
    version="0.0.6",
    description="A tool to compute the reliability of Machine Learning predictions",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/bmi-labmedinfo/Reliability",
    author="LorenzoPeracchio",
    author_email="lorenzo.peracchio01@universitadipavia.it",
    license="MIT",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.10",
        "Operating System :: OS Independent"
    ],
    install_require=["numpy==1.25.0", "scikit-learn==1.2.2", "pytorch==2.0.1", "plotly==5.9.0", "matplotlib==3.7.1"],
    extras_require={
        "dev": ["pytest>=7.0", "twine>=4.0.2"]
    },
    python_requires=">=3.6"
)

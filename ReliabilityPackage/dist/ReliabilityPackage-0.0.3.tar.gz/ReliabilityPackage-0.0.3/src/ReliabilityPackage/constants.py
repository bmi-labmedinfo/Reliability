SEED: int = 42
